package com.example.task

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.task.helper.DbHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class SaveTodoActivity : AppCompatActivity() {
    private lateinit var title: TextInputLayout
    private lateinit var description: TextInputLayout
    private lateinit var date: TextInputEditText
    private lateinit var fabsave: FloatingActionButton
    private lateinit var calendar: Calendar
    private lateinit var dateListener: DatePickerDialog.OnDateSetListener
    var finalDate = 0L
    private val databaseHelper = DbHelper(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save_todo)

        fabsave = findViewById(R.id.fab_send)
        title = findViewById(R.id.et_title)
        description = findViewById(R.id.et_description)
        // date = findViewById(R.id.et_date)

        /*date.setOnClickListener {
            setDateListener()
        }*/

        fabsave.setOnClickListener {
            saveTodo()
        }
    }

    /*
    private fun setDateListener() {
        calendar = Calendar.getInstance()
        dateListener = DatePickerDialog.OnDateSetListener { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, month)
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateDate()
        }
    }



    private fun updateDate() {
        val dateFormat = "EEE, d MMM yyyy"
        val sdf = SimpleDateFormat(dateFormat)
        finalDate = calendar.time.time
        date.setText(sdf.format(calendar.time))
    }

     */

    private fun saveTodo() {
        if (title.editText?.text.toString().isEmpty()) {
            title.error = "Enter title"
            title.requestFocus()
            return
        }
        if (description.editText?.text.toString().isEmpty()) {
            description.error = "Enter Description"
            description.requestFocus()
            return
        }
        if (notEmpty()) {
            databaseHelper.saveNote(
                title.editText?.text.toString(),
                description.editText?.text.toString()
            )
            Toast.makeText(this, "Todo saved", Toast.LENGTH_LONG).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun notEmpty(): Boolean {
        return (title.editText?.text.toString().isNotEmpty() && description.editText?.text.toString().isNotEmpty())
    }
}
