package com.example.task.util

const val TABLE_NAME = "NoteTable"
const val COLUMN_NAME_TITLE = "Title"
const val COLUMN_NAME_DESCRIPTION = "Description"
const val COLUMN_NAME_TIMESTAMP = "Timestamp"
const val COLUMN_NAME_COMPLETED = "status"
