package com.example.task.model

data class Todo(
    val id: Int,
    val title: String,
    val desc: String
    // val timestamp: String
)
