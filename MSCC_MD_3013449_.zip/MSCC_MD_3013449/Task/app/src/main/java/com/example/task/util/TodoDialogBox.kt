package com.example.task.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.BaseColumns
import android.widget.Toast
import com.example.task.MainActivity
import com.example.task.R
import com.example.task.UpdateTodoActivity
import com.example.task.helper.DbHelper
import com.example.task.model.Todo
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class TodoDialogBox {

    fun updateTodoDialog(context: Context, todo: Todo) {
        val dialog = MaterialAlertDialogBuilder(context)
        dialog.setTitle("Edit")
        dialog.setMessage("Do you want to update?")
        dialog.setIcon(R.drawable.ic_baseline_edit_24)

        dialog.setPositiveButton("Update") { _, _ ->
            val intent = Intent(context, UpdateTodoActivity::class.java).apply {
                putExtra(BaseColumns._ID, todo.id)
                putExtra(COLUMN_NAME_TITLE, todo.title)
                putExtra(COLUMN_NAME_DESCRIPTION, todo.desc)
            }
            context.startActivity(intent)
            (context as Activity).finish()
        }
        dialog.setNeutralButton("Cancel") { _, _ ->
            Toast.makeText(context, "Cancelled", Toast.LENGTH_LONG).show()
        }
        dialog.create()
        dialog.setCancelable(false)
        dialog.show()
    }

    fun deleteTodoDialog(context: Context, todo: Todo) {
        val databaseHelper = DbHelper(context)

        val dialog = MaterialAlertDialogBuilder(context)
        dialog.setTitle("Delete")
        dialog.setMessage("Do you really want to delete?")
        dialog.setIcon(R.drawable.ic_baseline_delete_24)
        dialog.setPositiveButton("Delete") { _, _ ->

            databaseHelper.deleteTodo(todo.id.toString())

            Toast.makeText(context, "Deleted!", Toast.LENGTH_SHORT).show()

            val intent = Intent(context, MainActivity::class.java)
            context.startActivity(intent)
            (context as Activity).finish()
        }

        dialog.setNeutralButton("Cancel") { _, _ ->
            Toast.makeText(context, "Cancelled!", Toast.LENGTH_SHORT).show()
        }

        dialog.create()
        dialog.setCancelable(false)
        dialog.show()
    }
}
