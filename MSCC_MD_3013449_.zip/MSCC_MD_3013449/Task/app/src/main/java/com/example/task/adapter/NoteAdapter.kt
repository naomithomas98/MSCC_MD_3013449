package com.example.task.adapter
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.task.R
import com.example.task.model.Todo
import com.example.task.util.TodoDialogBox
import com.google.android.material.button.MaterialButton

class NoteAdapter(
    private val context: Context,
    private val notes: List<Todo>
) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {
    inner class NoteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.text_title)
        val description: TextView = view.findViewById(R.id.text_description)
        val btnEdit: MaterialButton = view.findViewById(R.id.btn_edit)
        val btnDelete: MaterialButton = view.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val noteLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.todo_item, parent, false)
        return NoteViewHolder(noteLayout)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val dialogBox = TodoDialogBox()
        val note = notes[position]
        holder.title.text = note.title
        holder.description.text = note.desc

        holder.btnEdit.setOnClickListener {
            dialogBox.updateTodoDialog(context, note)
        }
        holder.btnDelete.setOnClickListener {
            dialogBox.deleteTodoDialog(context, note)
        }
    }

    override fun getItemCount(): Int {
        return notes.size
    }
}
